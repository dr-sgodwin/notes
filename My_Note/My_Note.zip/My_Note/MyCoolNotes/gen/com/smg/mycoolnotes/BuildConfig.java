/** Automatically generated file. DO NOT MODIFY */
package com.smg.mycoolnotes;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}